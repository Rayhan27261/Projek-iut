# RSTARM 1.1.0 - Build from Android phone

Project ini bisa dibangun tanpa laptop menggunakan GitHub Actions (kompilasi di cloud).

## Langkah lewat HP
1. Ekstrak ZIP ini menggunakan ZArchiver.
2. Buka github.com di Chrome dan masuk/buat akun GitHub.
3. Buat repository baru bernama `rstarm-android` (boleh Private).
4. Upload seluruh isi folder `RSTARM-Android-Full` ke root repository. Pastikan folder `.github/workflows` ikut ter-upload.
5. Buka tab **Actions** di repository.
6. Jika diminta, pilih **I understand my workflows, go ahead and enable them**.
7. Pilih workflow **Build RSTARM APK**, tekan **Run workflow**.
8. Tunggu sampai proses selesai dengan tanda centang hijau.
9. Buka hasil run, gulir ke **Artifacts**, unduh `RSTARM-debug-APK`.
10. Ekstrak file artifact ZIP, lalu instal `app-debug.apk` di HP.

## Catatan
- Build ini menghasilkan APK debug untuk pengujian, bukan APK rilis bertanda tangan.
- Jika build gagal, buka log job dan kirim screenshot error-nya agar bisa diperbaiki.
- Project ini adalah pemutar musik lokal/offline dasar. Belum ada katalog streaming online.
