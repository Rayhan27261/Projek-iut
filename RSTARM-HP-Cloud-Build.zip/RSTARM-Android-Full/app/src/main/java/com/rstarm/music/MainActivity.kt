package com.rstarm.music

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

private val BG = Color(0xFF090A0F)
private val SURFACE = Color(0xFF151821)
private val PURPLE = Color(0xFFAA8CFF)
private val MUTED = Color(0xFF9295A3)

data class Track(val uri: String, val title: String, val artist: String, val duration: Long = 0L)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent { RstarmApp(this, player) }
    }
    override fun onDestroy() { player.release(); super.onDestroy() }
}

private fun loadTracks(context: Context): List<Track> {
    val raw = context.getSharedPreferences("rstarm", Context.MODE_PRIVATE).getString("tracks", "[]") ?: "[]"
    return runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Track(o.getString("uri"), o.optString("title", "Unknown"), o.optString("artist", "Local audio"), o.optLong("duration"))
        }
    }.getOrDefault(emptyList())
}
private fun saveTracks(context: Context, tracks: List<Track>) {
    val arr = JSONArray()
    tracks.forEach { t -> arr.put(JSONObject().put("uri", t.uri).put("title", t.title).put("artist", t.artist).put("duration", t.duration)) }
    context.getSharedPreferences("rstarm", Context.MODE_PRIVATE).edit().putString("tracks", arr.toString()).apply()
}
private fun loadSet(context: Context, key: String): Set<String> =
    context.getSharedPreferences("rstarm", Context.MODE_PRIVATE).getStringSet(key, emptySet())?.toSet() ?: emptySet()
private fun saveSet(context: Context, key: String, value: Set<String>) {
    context.getSharedPreferences("rstarm", Context.MODE_PRIVATE).edit().putStringSet(key, value).apply()
}
private fun loadLyrics(context: Context, uri: String): String =
    context.getSharedPreferences("rstarm", Context.MODE_PRIVATE).getString("lyrics_$uri", "") ?: ""
private fun saveLyrics(context: Context, uri: String, text: String) {
    context.getSharedPreferences("rstarm", Context.MODE_PRIVATE).edit().putString("lyrics_$uri", text).apply()
}
private fun fileName(context: Context, uri: Uri): String {
    return runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Unknown audio"
}
private fun ms(value: Long): String {
    val s = (value / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun RstarmApp(context: Context, player: ExoPlayer) {
    var tracks by remember { mutableStateOf(loadTracks(context)) }
    var favorites by remember { mutableStateOf(loadSet(context, "favorites")) }
    var playlists by remember { mutableStateOf(loadSet(context, "playlists")) }
    var currentUri by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var showPlayer by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var lyricsText by remember { mutableStateOf("") }
    var showPlaylistDialog by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    var shuffle by remember { mutableStateOf(false) }
    var repeatOne by remember { mutableStateOf(false) }

    val current = tracks.firstOrNull { it.uri == currentUri }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val incoming = uris.map { uri ->
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            Track(uri.toString(), fileName(context, uri).substringBeforeLast('.'), "On your device")
        }
        tracks = (tracks + incoming).distinctBy { it.uri }
        saveTracks(context, tracks)
    }
    fun playTrack(track: Track, queue: List<Track> = tracks) {
        currentUri = track.uri
        val list = if (queue.isEmpty()) listOf(track) else queue
        player.setMediaItems(list.map { MediaItem.fromUri(it.uri) }, list.indexOfFirst { it.uri == track.uri }.coerceAtLeast(0), 0L)
        player.prepare()
        player.play()
        showPlayer = true
    }
    fun toggleFavorite(track: Track) {
        favorites = if (track.uri in favorites) favorites - track.uri else favorites + track.uri
        saveSet(context, "favorites", favorites)
    }
    LaunchedEffect(player) {
        while (true) {
            playing = player.isPlaying
            position = player.currentPosition.coerceAtLeast(0)
            duration = player.duration.takeIf { it > 0 } ?: (current?.duration ?: 0L)
            currentUri = player.currentMediaItem?.localConfiguration?.uri?.toString() ?: currentUri
            delay(350)
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = SURFACE, primary = PURPLE, onBackground = Color.White, onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(BG).statusBarsPadding()) {
            if (showPlayer && current != null) {
                NowPlayingScreen(
                    track = current, playing = playing, position = position, duration = duration,
                    favorite = current.uri in favorites, shuffle = shuffle, repeatOne = repeatOne,
                    lyrics = lyricsText, showLyrics = showLyrics,
                    onBack = { showPlayer = false }, onToggle = { if (player.isPlaying) player.pause() else player.play() },
                    onPrevious = { player.seekToPreviousMediaItem() }, onNext = { player.seekToNextMediaItem() },
                    onSeek = { player.seekTo(it) }, onFavorite = { toggleFavorite(current) },
                    onShuffle = { shuffle = !shuffle; player.shuffleModeEnabled = shuffle },
                    onRepeat = { repeatOne = !repeatOne; player.repeatMode = if (repeatOne) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF },
                    onLyrics = { showLyrics = !showLyrics; lyricsText = loadLyrics(context, current.uri) },
                    onSaveLyrics = { saveLyrics(context, current.uri, it); lyricsText = it }
                )
            } else {
                Header(onImport = { picker.launch(arrayOf("audio/*")) })
                when (tab) {
                    "Library" -> TrackList("Your Library", tracks, currentUri, favorites, onTrack = { playTrack(it) }, onFavorite = { toggleFavorite(it) }, onImport = { picker.launch(arrayOf("audio/*")) })
                    "Favorites" -> TrackList("Favorites", tracks.filter { it.uri in favorites }, currentUri, favorites, onTrack = { playTrack(it) }, onFavorite = { toggleFavorite(it) }, onImport = { picker.launch(arrayOf("audio/*")) })
                    "Search" -> Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                        Text("Search your music", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))
                        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Song or artist") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                        Spacer(Modifier.height(12.dp))
                        TrackList("Results", tracks.filter { it.title.contains(query, true) || it.artist.contains(query, true) }, currentUri, favorites, onTrack = { playTrack(it) }, onFavorite = { toggleFavorite(it) }, onImport = { picker.launch(arrayOf("audio/*")) })
                    }
                    "Playlists" -> Column(Modifier.fillMaxSize().padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Playlists", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            FilledTonalIconButton(onClick = { showPlaylistDialog = true }) { Icon(Icons.Default.Add, null) }
                        }
                        Spacer(Modifier.height(12.dp))
                        if (playlists.isEmpty()) Text("Create a playlist to organize your music.", color = MUTED)
                        playlists.forEach { name -> Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.QueueMusic, null, tint = PURPLE)
                            Text(name, modifier = Modifier.weight(1f).padding(start = 12.dp), fontWeight = FontWeight.SemiBold)
                            IconButton(onClick = { playlists = playlists - name; saveSet(context, "playlists", playlists) }) { Icon(Icons.Default.DeleteOutline, null, tint = MUTED) }
                        } }
                    }
                    else -> HomeScreen(tracks.size, favorites.size, onImport = { picker.launch(arrayOf("audio/*")) }, onLibrary = { tab = "Library" }, onPlaylists = { tab = "Playlists" })
                }
                Spacer(Modifier.weight(1f))
                if (current != null) MiniPlayer(current, playing, position, duration, onOpen = { showPlayer = true }, onToggle = { if (player.isPlaying) player.pause() else player.play() }, onNext = { player.seekToNextMediaItem() })
                NavigationBar(containerColor = BG) {
                    val destinations = listOf("Home" to Icons.Default.Home, "Search" to Icons.Default.Search, "Library" to Icons.Default.LibraryMusic, "Favorites" to Icons.Default.Favorite, "Playlists" to Icons.Default.QueueMusic)
                    destinations.forEach { (name, icon) ->
                        NavigationBarItem(selected = tab == name, onClick = { tab = name }, icon = { Icon(icon, null) }, label = { Text(name, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = PURPLE, indicatorColor = SURFACE, selectedTextColor = PURPLE))
                    }
                }
            }
        }
        if (showPlaylistDialog) AlertDialog(
            onDismissRequest = { showPlaylistDialog = false },
            title = { Text("New playlist") },
            text = { OutlinedTextField(playlistName, { playlistName = it }, label = { Text("Playlist name") }, singleLine = true) },
            confirmButton = { TextButton(onClick = {
                if (playlistName.isNotBlank()) { playlists = playlists + playlistName.trim(); saveSet(context, "playlists", playlists) }
                playlistName = ""; showPlaylistDialog = false
            }) { Text("Create") } },
            dismissButton = { TextButton(onClick = { showPlaylistDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun Header(onImport: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 21.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("RSTARM", fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("YOUR SOUND. YOUR SPACE.", fontSize = 9.sp, color = MUTED, letterSpacing = 2.sp)
        }
        IconButton(onClick = onImport) { Icon(Icons.Default.Add, "Import music", tint = PURPLE) }
    }
}
@Composable
private fun HomeScreen(count: Int, favorites: Int, onImport: () -> Unit, onLibrary: () -> Unit, onPlaylists: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(25.dp)).background(Brush.linearGradient(listOf(Color(0xFF3B2B70), Color(0xFF171A2A)))).padding(22.dp)) {
                Column {
                    Text("A WORLD OF SOUND", color = Color(0xFFD1C4FF), fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Your music.\nYour universe.", fontSize = 31.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onImport, colors = ButtonDefaults.buttonColors(containerColor = PURPLE, contentColor = Color.White)) { Icon(Icons.Default.LibraryMusic, null); Spacer(Modifier.width(8.dp)); Text("Import music") }
                }
            }
        }
        item { Text("Your space", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                HomeTile("Library", "$count tracks", Icons.Default.MusicNote, Modifier.weight(1f), onLibrary)
                HomeTile("Favorites", "$favorites saved", Icons.Default.Favorite, Modifier.weight(1f), onLibrary)
            }
        }
        item { HomeTile("Playlists", "Build your own collections", Icons.Default.QueueMusic, Modifier.fillMaxWidth(), onPlaylists) }
        item { Text("Import audio files from your device to start listening.", color = MUTED, fontSize = 13.sp) }
    }
}
@Composable
private fun HomeTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(17.dp)).background(SURFACE).clickable(onClick = onClick).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = PURPLE, modifier = Modifier.size(25.dp))
        Column(Modifier.padding(start = 10.dp)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, color = MUTED, fontSize = 11.sp) }
    }
}
@Composable
private fun TrackList(title: String, tracks: List<Track>, currentUri: String?, favorites: Set<String>, onTrack: (Track) -> Unit, onFavorite: (Track) -> Unit, onImport: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("${tracks.size} songs", color = MUTED, fontSize = 12.sp) }
            IconButton(onClick = onImport) { Icon(Icons.Default.Add, null, tint = PURPLE) }
        }
        Spacer(Modifier.height(10.dp))
        if (tracks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.LibraryMusic, null, tint = PURPLE, modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(10.dp)); Text("Nothing here yet", fontWeight = FontWeight.Bold)
                    Text("Import audio files from your phone", color = MUTED, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp)); Button(onClick = onImport) { Text("Import music") }
                }
            }
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            items(tracks, key = { it.uri }) { track ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (track.uri == currentUri) SURFACE else Color.Transparent).clickable { onTrack(track) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(43.dp).clip(RoundedCornerShape(11.dp)).background(Color(0xFF29233F)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = PURPLE) }
                    Column(Modifier.weight(1f).padding(start = 11.dp)) {
                        Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(track.artist, color = MUTED, fontSize = 11.sp)
                    }
                    IconButton(onClick = { onFavorite(track) }) { Icon(if (track.uri in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (track.uri in favorites) PURPLE else MUTED) }
                }
            }
        }
    }
}
@Composable
private fun MiniPlayer(track: Track, playing: Boolean, position: Long, duration: Long, onOpen: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp).clip(RoundedCornerShape(16.dp)).background(SURFACE).clickable(onClick = onOpen).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Album, null, tint = PURPLE, modifier = Modifier.size(35.dp))
            Column(Modifier.weight(1f).padding(start = 9.dp)) {
                Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(track.artist, color = MUTED, fontSize = 10.sp)
            }
            IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null) }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null) }
        }
        LinearProgressIndicator(progress = { if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth().height(3.dp).clip(CircleShape), color = PURPLE, trackColor = Color.DarkGray)
    }
}
@Composable
private fun NowPlayingScreen(
    track: Track, playing: Boolean, position: Long, duration: Long, favorite: Boolean,
    shuffle: Boolean, repeatOne: Boolean, lyrics: String, showLyrics: Boolean,
    onBack: () -> Unit, onToggle: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit,
    onSeek: (Long) -> Unit, onFavorite: () -> Unit, onShuffle: () -> Unit, onRepeat: () -> Unit,
    onLyrics: () -> Unit, onSaveLyrics: (String) -> Unit
) {
    var draft by remember(track.uri) { mutableStateOf(lyrics) }
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.KeyboardArrowDown, "Back") }
            Text("NOW PLAYING", modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = MUTED, fontSize = 11.sp, letterSpacing = 2.sp)
            IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = PURPLE) }
        }
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF45336F), Color(0xFF171B29)))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Album, null, tint = Color(0xFFBDA9FF), modifier = Modifier.size(150.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text(track.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(track.artist, color = MUTED)
        Spacer(Modifier.height(16.dp))
        Slider(value = if (duration > 0) position.coerceIn(0, duration).toFloat() else 0f, onValueChange = { onSeek(it.toLong()) }, valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()), colors = SliderDefaults.colors(thumbColor = PURPLE, activeTrackColor = PURPLE))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(ms(position), color = MUTED, fontSize = 11.sp); Text(ms(duration), color = MUTED, fontSize = 11.sp) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, null, tint = if (shuffle) PURPLE else MUTED) }
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null, modifier = Modifier.size(32.dp)) }
            FilledIconButton(onClick = onToggle, modifier = Modifier.size(62.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = PURPLE)) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, modifier = Modifier.size(34.dp), tint = Color.White) }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, modifier = Modifier.size(32.dp)) }
            IconButton(onClick = onRepeat) { Icon(Icons.Default.RepeatOne, null, tint = if (repeatOne) PURPLE else MUTED) }
        }
        TextButton(onClick = onLyrics, modifier = Modifier.align(Alignment.CenterHorizontally)) { Icon(Icons.Default.Lyrics, null); Spacer(Modifier.width(6.dp)); Text(if (showLyrics) "Hide lyrics" else "Lyrics") }
        if (showLyrics) {
            OutlinedTextField(draft, { draft = it }, modifier = Modifier.fillMaxWidth().height(115.dp), placeholder = { Text("Paste or write lyrics for this song…") })
            Button(onClick = { onSaveLyrics(draft) }, modifier = Modifier.align(Alignment.End)) { Text("Save lyrics") }
        }
        Spacer(Modifier.height(12.dp))
    }
}
